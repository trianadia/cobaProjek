// ============================================
// VoteKampus - Simple Router
// ============================================

const Router = {
    routes: {},
    currentRoute: null,
    
    // Initialize router
    init() {
        window.addEventListener('hashchange', () => this.handleRoute());
        window.addEventListener('load', () => this.handleRoute());
    },
    
    // Register a route
    register(path, handler) {
        this.routes[path] = handler;
    },
    
    // Navigate to a route
    navigate(path) {
        window.location.hash = path;
    },
    
    // Handle route changes
    handleRoute() {
        const hash = window.location.hash.slice(1) || '/';
        const [path, ...params] = hash.split('/').filter(Boolean);
        const routePath = '/' + (path || '');
        
        // Find matching route
        if (this.routes[routePath]) {
            this.currentRoute = routePath;
            this.routes[routePath](params);
        } else {
            // Default to home
            this.navigate('/');
        }
    },
    
    // Get current route
    getCurrentRoute() {
        return this.currentRoute;
    }
};
